﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using WPF_MasterDetailApp;
using WPF_MasterDetailApp.Models;

namespace WPF_MasterDetailApp.BusinessLayer
{
    public class ProductBL
    {
        #region ENUMS



        #endregion

        #region FIELDS
        ProductWindowPresenter _productWindowPresenter;
        ProductWindowView _productWindowView;

        #endregion

        #region PROPERTIES

        #endregion

        #region CONSTRUCTORS
        public ProductBL()
        {
            //
            // instantiate the view model and initialize the data set
            //

            _productWindowPresenter = new ProductWindowPresenter(GetCompanyData(), GetProductData());

            //
            // instantiate, set the data context, and show the Main Window
            //
            _productWindowView = new ProductWindowView(_productWindowPresenter);
            _productWindowView.DataContext = _productWindowPresenter;
            _productWindowView.Show();
        }

        private Product GetProductData()
        {

            return new Product()
            {
                Id = 0,
                ChasisColor = "Black",
                KeyboardName = "Strafe MK.2",
                Key = Product.KeyType.Mechanical,
                ShipDate = DateTime.Parse("7/7/7"),
                Switch = "Red",
                ImageFileName = "fred_flintstone.jpg",
                Price = 120,
                RGB = "Full"
            };
        }

        private Company GetCompanyData()
        {
            Company company = new Company();

            company.Name = "Acme Agency";
            company.Address = "11 Front Street";
            company.City = "Traverse City";

            return company;
        }

        #endregion

        #region METHODS



        #endregion

        #region EVENTS


        #endregion

    }
}
