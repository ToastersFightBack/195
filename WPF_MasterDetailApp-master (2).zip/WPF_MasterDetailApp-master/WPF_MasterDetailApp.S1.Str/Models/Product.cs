﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPF_MasterDetailApp.Models
{
    public class Product
    {
        #region ENUMS

        public enum KeyType { Mechanical, Membrane}

        #endregion

        #region FIELDS

        private int _id;
        private string _keyboardName;
        private string _chasiscolor;
        private string _switch;
        private KeyType _key;
        private string _imageFileName;
        private string _description;
        private DateTime _shipdate;
        private double _averageAnnualGross;
        private int _price;
        private string _rgb;

        public string RGB
        {
            get { return _rgb; }
            set { _rgb = value; }
        }

        public int Price
        {
            get { return _price; }
            set { _price = value; }
        }

        #endregion

        #region PROPERTIES

        public int Id
        {
            get { return _id; }
            set { _id = value; }
        }

        public string KeyboardName
        {  
            get { return _keyboardName; }
            set
            {
                _keyboardName = value;

            }
        }

        public string ChasisColor
        {
            get { return _chasiscolor; }
            set
            {
                _chasiscolor = value;

            }
        }

        public string Switch
        {
            get { return _switch; }
            set { _switch = value; }
        }

        public KeyType Key
        {
            get { return _key; }
            set { _key = value; }
        }

        public string ImageFileName
        {
            get { return _imageFileName; }
            set { _imageFileName = value; }
        }

        public string Description
        {
            get { return _description; }
            set { _description = value; }
        }

        public DateTime ShipDate
        {
            get { return _shipdate; }
            set { _shipdate = value; }
        }

        public double AverageAnnualGross
        {
            get { return _averageAnnualGross; }
            set { _averageAnnualGross = value; }
        }

        

        public string ImageFilePath
        {
            get { return @"../Images/" + _imageFileName; }
        }

        #endregion

        #region CONSTRUCTORS

        public Product()
        {

        }

        #endregion

        #region METHODS


        #endregion

        #region EVENTS



        #endregion
    }
}
